# GLOAR TECH — Instrucciones de Uso

## Estructura del proyecto

```
GLOAR-TECH/
├── index.html              ← Abrir esto en el navegador
├── pages/login.html        ← Página de login
├── src/
│   ├── js/
│   │   ├── config.js       ← URL del backend (no tocar)
│   │   ├── api.js          ← Comunicación con el servidor
│   │   ├── app.js          ← Lógica principal
│   │   ├── ui.js           ← Interfaz
│   │   ├── auth.js         ← Autenticación
│   │   ├── store.js        ← Cotizaciones locales
│   │   └── utils.js        ← Utilidades
│   └── styles/
│       ├── variables.css
│       ├── main.css
│       └── login.css
├── image/                  ← Logos e iconos
└── backend-local/          ← Servidor Node.js
    ├── server.js
    ├── package.json
    └── gloartech.db        ← Base de datos (se crea sola)
```

---

## Cómo usar cada día

### 1. Iniciar el servidor (OBLIGATORIO antes de abrir la app)

```bash
cd backend-local
npm start
```

Dejar esa terminal abierta mientras usas la app.

### 2. Abrir la app

Abrir `index.html` en el navegador.

---

## Credenciales por defecto

| Rol           | Contraseña    |
|---------------|---------------|
| Administrador | `admin123`    |
| Usuario       | `usuario123`  |

Se pueden cambiar desde **Configuración** (solo admin).

---

## Primera vez

1. Instalar dependencias (solo una vez):
   ```bash
   cd backend-local
   npm install
   ```
2. Iniciar servidor: `npm start`
3. Abrir `index.html`
4. Ir a **Configuración → Iniciar Base de Datos** (opcional, se hace automático)
5. Ir a **Categorías** y crear las categorías que uses
6. Ir a **Registrar Producto** y comenzar a cargar productos

---

## Backup

Tu base de datos está en `backend-local/gloartech.db`.  
Copia ese archivo para hacer backup. Para restaurar, reemplázalo.
